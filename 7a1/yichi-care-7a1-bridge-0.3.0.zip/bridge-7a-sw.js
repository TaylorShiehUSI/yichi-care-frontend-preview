/*
 * 憶起照顧 7A：service worker 端的路由（接在既有 6B 橋接的 NotebookLM 驅動之前）。
 *
 * 用法（在既有 6B service worker 最上方）：
 *   classic SW： importScripts('bridge-7a-sw.js');
 *   module  SW： import './bridge-7a-sw.js';
 * 然後：
 *   self.Yichi7a.install({
 *     ask: async ({ question, mode, signal, onProgress }) => {
 *       // mode === 'new'      → 第 1 題（6B 既有「新提問」流程）
 *       // mode === 'followup' → 在同一個 NotebookLM 對話接續提問（6A 已驗證的追問流程）
 *       // 必須回傳 { text: string, citations: [{ n: number, title: string, excerpt: string }] }
 *       // 失敗時 throw，並在 error.code 放：LOGIN_REQUIRED | NOTEBOOK_UNAVAILABLE | TIMEOUT | BRIDGE_ERROR
 *       // 收到 signal.aborted 時停止等待，不得自動重送。
 *     },
 *   });
 *
 * 本檔只處理：來源檢查、單一進行中請求、對話接續檢查、逾時、保活心跳、回傳正規化。
 * 不保存問題或回答文字；chrome.storage.session 只記 sessionKey 與輪數。
 */
(() => {
  'use strict';
  const ALLOWED_ORIGIN = 'https://taylorshiehusi.github.io';
  const ALLOWED_PREFIX = ALLOWED_ORIGIN + '/yichi-care-frontend-preview/7a1/';
  const ASK_TIMEOUT_MS = 170_000;
  const HEARTBEAT_MS = 20_000; // 有訊息往來時 MV3 service worker 不會因閒置被停止
  const MAX_QUESTION = 300;
  const KNOWN = new Set(['LOGIN_REQUIRED', 'NOTEBOOK_UNAVAILABLE', 'TIMEOUT', 'BRIDGE_ERROR']);
  const STATE_KEY = 'yichi7a.session';
  const isId = (s) => typeof s === 'string' && /^[0-9a-f-]{36}$/i.test(s);

  let installed = false;
  let inflight = false;

  function senderOk(sender) {
    if (!sender || sender.id !== chrome.runtime.id) return false;
    if (typeof sender.url !== 'string' || !sender.url.startsWith(ALLOWED_PREFIX)) return false;
    if (sender.origin !== undefined && sender.origin !== ALLOWED_ORIGIN) return false;
    return !!sender.tab; // 必須來自分頁中的 content script
  }

  async function loadState() {
    try { return (await chrome.storage.session.get(STATE_KEY))[STATE_KEY] || null; } catch { return null; }
  }
  async function saveState(s) {
    try { await chrome.storage.session.set({ [STATE_KEY]: s }); } catch { /* 只影響接續檢查 */ }
  }

  function clean(res) {
    const text = typeof res?.text === 'string' ? res.text.slice(0, 20000).trim() : '';
    if (!text) { const e = new Error('沒有取得回答內容'); e.code = 'BRIDGE_ERROR'; throw e; }
    const list = Array.isArray(res.citations) ? res.citations.slice(0, 30) : [];
    const citations = list.map((c, i) => ({
      n: Number.isInteger(c?.n) ? c.n : i + 1,
      title: typeof c?.title === 'string' ? c.title.slice(0, 300) : '',
      excerpt: typeof c?.excerpt === 'string' ? c.excerpt.slice(0, 4000) : '',
    }));
    return { text, citations, citationsComplete: res.citationsComplete === true && citations.length === res.citations.length };
  }

  async function handle(port, req, driver) {
    const send = (m) => { try { port.postMessage({ id: req.id, ...m }); } catch { /* 頁面已關閉 */ } };
    const fail = (code, message = '') => send({ type: 'error', code, message });

    const question = typeof req.question === 'string' ? req.question.replace(/[\u0000-\u001f\u007f]/g, ' ').trim() : '';
    if (!isId(req.id) || !isId(req.sessionKey) || !Number.isInteger(req.turn) || req.turn < 1 ||
        (req.mode !== 'new' && req.mode !== 'followup') || !question || question.length > MAX_QUESTION ||
        (req.mode === 'new') !== (req.turn === 1)) {
      return fail('BAD_REQUEST');
    }
    if (inflight) return fail('BUSY');

    // 追問必須接在同一個 sessionKey 的上一輪之後；其他分頁開始新對話後，舊分頁的追問會被拒絕
    inflight = true;
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), ASK_TIMEOUT_MS);
    const beat = setInterval(() => send({ type: 'progress', stage: 'waiting' }), HEARTBEAT_MS);
    const onDisconnect = () => ac.abort();
    port.onDisconnect.addListener(onDisconnect);
    try {
      const caller = port.sender.tab.id;
      const st = await loadState();
      if (req.mode === 'followup' && (!st || st.caller !== caller || st.sessionKey !== req.sessionKey || st.turn !== req.turn - 1)) {
        return fail('SESSION_MISMATCH');
      }
      if (ac.signal.aborted) return;
      if (req.mode === 'new') await saveState(null);
      const out = await Promise.race([
        driver.ask({ question, mode: req.mode, sessionKey: req.sessionKey, signal: ac.signal, onProgress: (stage) => send({ type: 'progress', stage: String(stage || '') }) }),
        new Promise((_, rej) => ac.signal.addEventListener('abort', () => { const e = new Error('timeout'); e.code = 'TIMEOUT'; rej(e); })),
      ]);
      const res = clean(out);
      await saveState({ caller, sessionKey: req.sessionKey, turn: req.turn });
      send({ type: 'result', sessionKey: req.sessionKey, turn: req.turn, text: res.text, citations: res.citations, citationsComplete: res.citationsComplete });
    } catch (e) {
      const code = KNOWN.has(e?.code) ? e.code : 'BRIDGE_ERROR';
      console.warn('[yichi-7a1] ask failed', code, e?.message);
      fail(code, code === 'BRIDGE_ERROR' ? String(e?.message || '').slice(0, 200) : '');
    } finally {
      port.onDisconnect.removeListener?.(onDisconnect);
      clearTimeout(timer);
      clearInterval(beat);
      inflight = false;
    }
  }

  function install(driver) {
    if (installed) return;
    if (!driver || typeof driver.ask !== 'function') throw new Error('Yichi7a.install 需要 { ask }');
    installed = true;
    chrome.runtime.onConnect.addListener((port) => {
      if (port.name !== 'yichi-7a1') return;
      if (!senderOk(port.sender)) { console.warn('[yichi-7a1] 拒絕來源', port.sender?.url); port.disconnect(); return; }
      port.onMessage.addListener((req) => { if (req?.type === 'ask') handle(port, req, driver); });
    });
  }

  self.Yichi7a = { install, ALLOWED_PREFIX };
})();
