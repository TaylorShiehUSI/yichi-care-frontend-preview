'use strict';

importScripts('bridge-7a-sw.js');

const notebookPath = '/notebook/8242fbbf-ed59-4541-93db-4e3c7eb4d275';
const notebookOrigins = ['https://notebooklm.google.com', 'https://notebook.google.com'];
const notebookUrls = notebookOrigins.map(origin => origin + notebookPath);
const tabKey = 'yichi7a.notebookTab';

function fail(code, detail) {
  throw Object.assign(new Error(detail || code), { code });
}

self.Yichi7a.install({
  async ask({ question, mode, sessionKey, signal }) {
    const tabs = (await chrome.tabs.query({ url: notebookUrls.map(url => url + '*') }))
      .filter(tab => tab.url && notebookUrls.includes(tab.url.split(/[?#]/, 1)[0]));
    if (tabs.length !== 1) fail('NOTEBOOK_UNAVAILABLE');
    const [tab] = tabs;
    const saved = (await chrome.storage.session.get(tabKey))[tabKey];
    if (mode === 'followup' && (saved?.sessionKey !== sessionKey || saved?.tabId !== tab.id)) {
      fail('NOTEBOOK_UNAVAILABLE');
    }
    if (signal.aborted) fail('TIMEOUT');

    const requestId = crypto.randomUUID();
    const abort = () => chrome.tabs.sendMessage(tab.id, { type: 'ABORT', requestId }).catch(() => {});
    signal.addEventListener('abort', abort, { once: true });
    try {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: 'ASK', requestId, question });
      if (signal.aborted) fail('TIMEOUT');
      if (reply?.requestId !== requestId || reply.status !== 'ok') {
        const code = reply?.code || 'E_NOTEBOOK_DOM';
        fail(code === 'E_ANSWER_TIMEOUT' || code === 'E_CITATION_EXCERPT' ? 'TIMEOUT' : 'BRIDGE_ERROR', code);
      }
      await chrome.storage.session.set({ [tabKey]: { sessionKey, tabId: tab.id } });
      return {
        text: reply.answer,
        citationsComplete: reply.citationsComplete,
        citations: reply.citations.map(({ index, sourceTitle, excerpt }) => ({ n: index, title: sourceTitle, excerpt })),
      };
    } catch (error) {
      if (error.code) throw error;
      fail('NOTEBOOK_UNAVAILABLE');
    } finally {
      signal.removeEventListener('abort', abort);
    }
  },
});
