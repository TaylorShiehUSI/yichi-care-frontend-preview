/*
 * 憶起照顧 7A：試用頁 ⇄ 擴充功能 的 content script（只注入 7A 試用網址）。
 * 頁面 → window.postMessage({ns:'yichi-7a1/page'}) → 本檔 → runtime port 'yichi-7a1' → service worker
 * service worker → port → 本檔 → window.postMessage({ns:'yichi-7a1/ext'}) → 頁面
 *
 * 只做轉送與基本檢查，不讀取頁面其他內容、不保存問題文字。
 */
(() => {
  'use strict';
  const ALLOWED_ORIGIN = 'https://taylorshiehusi.github.io';
  const ALLOWED_PATH = '/yichi-care-frontend-preview/7a1/';
  const NS_PAGE = 'yichi-7a1/page';
  const NS_EXT = 'yichi-7a1/ext';
  const V = 1;

  // manifest 的 matches 已限制網址；這裡再檢查一次，避免日後誤改 matches 而擴大範圍
  if (location.origin !== ALLOWED_ORIGIN || !location.pathname.startsWith(ALLOWED_PATH)) return;
  if (window.__yichi7aBridge) return;
  window.__yichi7aBridge = true;

  const reply = (msg) => window.postMessage({ ns: NS_EXT, v: V, ...msg }, ALLOWED_ORIGIN);
  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  const isId = (s) => typeof s === 'string' && /^[0-9a-f-]{36}$/i.test(s);

  let busy = false;

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== ALLOWED_ORIGIN) return;
    const d = e.data;
    if (!d || typeof d !== 'object' || d.ns !== NS_PAGE || d.v !== V || !isId(d.id)) return;

    if (!alive()) { reply({ id: d.id, type: 'error', code: 'EXTENSION_RELOADED' }); return; }

    if (d.type === 'ping') {
      reply({ id: d.id, type: 'pong', ext: { id: chrome.runtime.id, version: chrome.runtime.getManifest().version } });
      return;
    }
    if (d.type !== 'ask') return;

    if (busy) { reply({ id: d.id, type: 'error', code: 'BUSY' }); return; }
    const req = {
      type: 'ask',
      id: d.id,
      sessionKey: d.sessionKey,
      turn: d.turn,
      mode: d.mode,
      question: d.question,
    };
    if (!isId(req.sessionKey) || !Number.isInteger(req.turn) || req.turn < 1 ||
        (req.mode !== 'new' && req.mode !== 'followup') || typeof req.question !== 'string') {
      reply({ id: d.id, type: 'error', code: 'BAD_REQUEST' });
      return;
    }

    busy = true;
    let done = false;
    let port;
    try {
      port = chrome.runtime.connect({ name: 'yichi-7a1' });
    } catch {
      busy = false;
      reply({ id: d.id, type: 'error', code: 'EXTENSION_RELOADED' });
      return;
    }
    port.onMessage.addListener((m) => {
      if (!m || m.id !== req.id) return;
      if (m.type === 'progress') { reply({ id: req.id, type: 'progress', stage: String(m.stage || '') }); return; }
      if (m.type === 'result') {
        done = true;
        reply({ id: req.id, type: 'result', sessionKey: m.sessionKey, turn: m.turn, text: m.text, citations: m.citations, citationsComplete: m.citationsComplete });
      } else if (m.type === 'error') {
        done = true;
        reply({ id: req.id, type: 'error', code: m.code || 'BRIDGE_ERROR', message: m.message || '' });
      }
      if (done) { busy = false; try { port.disconnect(); } catch { /* 已斷線 */ } }
    });
    port.onDisconnect.addListener(() => {
      busy = false;
      if (!done) reply({ id: req.id, type: 'error', code: 'BRIDGE_ERROR', message: '擴充功能連線中斷' });
    });
    port.postMessage(req);
  });
})();
