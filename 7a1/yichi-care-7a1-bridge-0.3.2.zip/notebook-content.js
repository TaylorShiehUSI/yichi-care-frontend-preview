'use strict';

const NOTEBOOK_PATH = '/notebook/8242fbbf-ed59-4541-93db-4e3c7eb4d275';
const NOTEBOOK_HOSTS = ['notebooklm.google.com', 'notebook.google.com'];
const USER_CARD = 'mat-card.from-user-message-card-content';
const MODEL_CARD = 'mat-card.to-user-message-card-content';
const QUERY = 'textarea[aria-label="查詢方塊"], textarea[aria-label="Query box"]';
const DOCUMENT = 'source-viewer labs-tailwind-doc-viewer';
const sourceName = (text) => text.normalize('NFC').replace(/\s+/gu, ' ').trim();
let active;

function fail(code) {
  throw Object.assign(new Error(code), { code });
}

function visible(element) {
  return element instanceof HTMLElement && !!element.getClientRects().length;
}

function findButton(...labels) {
  return [...document.querySelectorAll('button')].find(button =>
    visible(button) && (labels.includes(button.getAttribute('aria-label')) || labels.includes(button.innerText.trim())));
}

async function waitFor(state, condition, code, ms = 3500) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    if (state.aborted) fail('E_ABORTED');
    const result = condition();
    if (result) return result;
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  fail(code);
}

async function getSelection(state) {
  const rows = () => [...document.querySelectorAll('input[type="checkbox"][aria-label^="選取「"], input[type="checkbox"][aria-label^="Select "]')].filter(visible);
  if (!rows().length) {
    const button = findViewerClose() || findButton('Sources', '來源');
    if (!button) fail('E_SOURCE_PANEL');
    button.click();
  }
  const options = await waitFor(state, () => rows().length && rows(), 'E_SOURCE_PANEL');
  const names = options.map(item => item.getAttribute('aria-label')
    .replace(/^選取「(.*)」$/, '$1').replace(/^Select (.+)$/, '$1')).map(sourceName);
  const selected = names.filter((_, index) => options[index].checked);
  const ambiguous = new Set(names).size !== names.length;
  if (!selected.length) fail('E_SOURCE_SELECTION');
  const chat = findButton('對話', 'Chat');
  if (!visible(document.querySelector(QUERY)) && chat) chat.click();
  const query = await waitFor(state, () => {
    const input = document.querySelector(QUERY);
    return visible(input) && input;
  }, 'E_QUERY_BOX');
  return { query, selected: selected.sort(), ambiguous };
}

function findViewerClose() {
  const wide = document.querySelector('button[mattooltip="關閉來源檢視畫面"]');
  return visible(wide) ? wide : findButton('返回', 'Back', 'Close source viewer');
}

function cardText(card) {
  return card.querySelector('mat-card-content')?.innerText.trim() ?? '';
}

function answerText(card) {
  const body = card.querySelector('mat-card-content');
  if (!body) return '';
  const copy = body.cloneNode(true);
  copy.querySelectorAll('thinking-chain-view, script, style, [hidden], [aria-hidden="true"]').forEach(element => element.remove());
  for (const control of copy.querySelectorAll('button, [role="button"]')) {
    const citation = /^\d+/.exec(control.querySelector('[aria-label]')?.getAttribute('aria-label') ?? control.getAttribute('aria-label') ?? '');
    control.replaceWith(citation && control.matches('button.citation-marker') ? '[' + citation[0] + ']' : '');
  }
  copy.setAttribute('aria-hidden', 'true');
  copy.style.cssText = 'position:fixed;left:-100000px;top:0;width:700px;pointer-events:none;';
  document.body.append(copy);
  try {
    return copy.innerText.trim();
  } finally {
    copy.remove();
  }
}

function markers(card) {
  return [...card.querySelectorAll('button.citation-marker')].map(button => {
    const label = button.querySelector('[aria-label]')?.getAttribute('aria-label') ??
      button.getAttribute('aria-label') ?? '';
    return { button, match: /^(\d+)[:：]\s*(.+)$/s.exec(label) };
  });
}

function turnAfterQuestion(index, question) {
  const user = document.querySelectorAll(USER_CARD)[index];
  if (!user || cardText(user) !== question) return null;
  const cards = [...document.querySelectorAll(USER_CARD + ',' + MODEL_CARD)];
  const model = cards[cards.indexOf(user) + 1];
  return model?.matches(MODEL_CARD) ? model : null;
}

async function closeViewer(state) {
  if (![...document.querySelectorAll(DOCUMENT)].some(visible)) return;
  const back = findViewerClose();
  if (!back) fail('E_CITATION_PANEL');
  back.click();
  await waitFor(state, () => ![...document.querySelectorAll(DOCUMENT)].some(visible), 'E_CITATION_PANEL');
}

async function readCitations(state, index, question, referenceLabels) {
  const citations = [];
  const failures = new Set();
  for (const [number, title] of referenceLabels) {
    try {
      await closeViewer(state);
      if (!visible(document.querySelector(QUERY))) findButton('對話', 'Chat')?.click();
      const marker = await waitFor(state, () => {
        const card = turnAfterQuestion(index, question);
        return card && markers(card).find(({ button, match }) =>
          visible(button) && match && Number(match[1]) === number && sourceName(match[2]) === title);
      }, 'E_CITATION_CHANGED');
      marker.button.click();
      const evidence = await waitFor(state, () => {
        const viewer = [...document.querySelectorAll('source-viewer')].find(element =>
          visible(element) && sourceName(element.querySelector('.source-title')?.innerText ?? '') === title);
        if (!viewer) return null;
        const documentView = viewer.querySelector('labs-tailwind-doc-viewer');
        if (!documentView) return null;
        const excerpt = [...documentView.querySelectorAll('.highlighted')]
          .filter(visible).map(element => element.innerText.trim()).filter(Boolean).join('\n');
        if (excerpt) return { excerpt };
        const images = [...documentView.querySelectorAll('image-element-view img.zoomable-img')].filter(visible);
        if (!documentView.innerText.trim() && images.some(image => image.complete && image.naturalWidth > 0)) {
          return { excerpt: '', kind: 'image-source' };
        }
        return null;
      }, 'E_CITATION_EXCERPT', 9000);
      citations.push({ index: number, sourceTitle: title, ...evidence });
    } catch (error) {
      if (state.aborted) throw error;
      failures.add(error.code ?? 'E_CITATION_EXCERPT');
    }
  }
  try {
    await closeViewer(state);
    if (!visible(document.querySelector(QUERY))) findButton('對話', 'Chat')?.click();
  } catch (error) {
    if (state.aborted) throw error;
    failures.add(error.code ?? 'E_CITATION_PANEL');
  }
  if (failures.size) console.info('[7A1] 引用擷取', [...failures].join(','));
  return { citations, complete: citations.length === referenceLabels.size && citations.every(citation => citation.excerpt) };
}

async function ask(state, question) {
  if (!NOTEBOOK_HOSTS.includes(location.hostname) || location.pathname !== NOTEBOOK_PATH) fail('E_NOTEBOOK');
  if (findButton('停止生成', 'Stop generating')) fail('E_BUSY');
  const { query, selected, ambiguous } = await getSelection(state);
  if (query.disabled || query.value.trim()) fail('E_BUSY');
  const index = document.querySelectorAll(USER_CARD).length;
  const setValue = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
  setValue.call(query, question);
  query.dispatchEvent(new Event('input', { bubbles: true }));
  const button = await waitFor(state, () => {
    const submit = [...(query.closest('form')?.querySelectorAll('button[aria-label="提交"], button[aria-label="Submit"], button[type="submit"]') ?? [])]
      .find(button => visible(button) && !button.disabled);
    return submit;
  }, 'E_SUBMIT');
  button.click();

  const card = await waitFor(state, () => {
    const result = turnAfterQuestion(index, question);
    const completed = result?.querySelector('button[aria-label="將模型回覆複製到剪貼簿"], button[aria-label="Copy model response to clipboard"]');
    return result && completed && !findButton('停止生成', 'Stop generating') && cardText(result) && result;
  }, 'E_ANSWER_TIMEOUT', 68000);
  const answer = answerText(card);
  if (!answer) fail('E_NO_ANSWER');
  const references = new Map();
  let citationsComplete = !ambiguous;
  for (const { match } of markers(card)) {
    const title = match ? sourceName(match[2]) : '';
    if (!match || !selected.includes(title) || (references.has(Number(match[1])) && references.get(Number(match[1])) !== title)) {
      citationsComplete = false;
      continue;
    }
    references.set(Number(match[1]), title);
  }
  let citations = [];
  try {
    const after = await getSelection(state);
    if (after.ambiguous || JSON.stringify(after.selected) !== JSON.stringify(selected)) citationsComplete = false;
    if (!ambiguous && references.size) {
      const read = await readCitations(state, index, question, references);
      citations = read.citations;
      citationsComplete &&= read.complete;
    }
  } catch (error) {
    if (state.aborted) throw error;
    console.info('[7A1] 來源勾選核對', error.code ?? 'E_SOURCE_PANEL');
    citationsComplete = false;
  }
  return { requestId: state.id, status: 'ok', answer, citations, citationsComplete: citationsComplete && citations.length > 0 };
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.tab) return false;
  if (message?.type === 'ABORT') {
    if (active?.id === message.requestId) active.aborted = true;
    return false;
  }
  if (message?.type !== 'ASK') return false;
  if (active) {
    respond({ requestId: message.requestId, status: 'error', code: 'E_BUSY' });
    return false;
  }
  const state = { id: message.requestId, aborted: false };
  active = state;
  ask(state, message.question)
    .then(respond, error => respond({ requestId: state.id, status: 'error', code: error.code ?? 'E_NOTEBOOK_DOM' }))
    .finally(() => { active = undefined; });
  return true;
});
